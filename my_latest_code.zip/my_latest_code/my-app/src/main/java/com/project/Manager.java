package com.project;

import java.util.Scanner;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Manager extends User {
	
	
	ExcelReader reader = new ExcelReader();
//	List<Manager> managerList = reader.readManagers("C:\\Shivaani\\java_bto_new\\sc2002-project (1)\\sc2002-project\\data\\ManagerList.xlsx");

	private List<Project> myProjects;
	Project selectedProject = null;
//	public Object activeProject;

	public Manager(String name, String nric, int age, String maritalStatus, String password) {
		super(name, nric, age, maritalStatus, password);
	}

	@Override
	public String getRole() {
		return "Manager";
	}

	String status = "ON";


	boolean exit = false;
	Project activeProject = null;
	LocalDate openDate = null;
	LocalDate closeDate = null;
	Scanner scanner = new Scanner(System.in);
	FilterMyProjects filter = new FilterMyProjects();
	
	//RETURN ACTIVE PROJECT OF THE MANAGER
	public void setActiveProject(List<Project> projectList) {
	    LocalDate today = LocalDate.now();

	    this.activeProject = projectList.stream()
	            .filter(project -> project.getManagerStr() != null && project.getManagerStr().equals(this.getNric()))
	            .filter(Project::isVisible)
	            .filter(project -> 
	                (today.isEqual(project.getOpenDate()) || today.isEqual(project.getCloseDate())) ||
	                (project.getOpenDate().isBefore(today) && project.getCloseDate().isAfter(today))
	            )
	            .findFirst()
	            .orElse(null);

	    if (this.activeProject != null) {
//	        System.out.println("Current Active Project: " + activeProject.getName());
	    } else {
	        UIHelper.printProjectHeader("You have no Active Project");
	    }
	}


	public Project getActiveProject(){
		return this.activeProject;
	}
	
	
	
	// CREATE A PROJECT
	public void createProject(Scanner scanner, List<Project> projectList){
		

		if (getActiveProject() != null){
			UIHelper.printDivider();
			System.out.println("\nYou already have an Active Project.....");
			System.out.println("You are not allowed to create a New Project!");
			return;
		}
		else {
			UIHelper.printAction("Create a New Project");
			
			DateTimeFormatter dateForm = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			
			System.out.println("Enter name of new Project:");
			String name = scanner.nextLine();

			System.out.println("Enter name of neighbourhood:");
			String neighbourhood = scanner.nextLine();


			System.out.println("Enter the number of 2-room flats:");
			int notype1 = Integer.parseInt(scanner.nextLine());

			System.out.println("Enter the price of 2-room flats:");
			double pricetype1 = Double.parseDouble(scanner.nextLine());


			System.out.println("Enter the number of 3-room flats:");
			int notype2 = Integer.parseInt(scanner.nextLine());

			System.out.println("Enter the price of 3-room flats:");
			double pricetype2 = Double.parseDouble(scanner.nextLine());

			System.out.println("Enter the number of officers to undertake the project:");
			int officerSlot = Integer.parseInt(scanner.nextLine());
			
			while (true) {
		        System.out.println("Enter application opening date (dd/MM/yyyy):");
		        openDate = LocalDate.parse(scanner.nextLine(), dateForm);

		        if (openDate.isAfter(LocalDate.now())) {
		            break;
		        } else {
		            System.out.println("Opening date must be after today!\n");
		        }
		    }


		    while (true) {
		        System.out.println("Enter application closing date (dd/MM/yyyy):");
		        closeDate = LocalDate.parse(scanner.nextLine(), dateForm);

		        if (closeDate.isAfter(openDate)) {
		            break;
		        } else {
		            System.out.println("Closing date must be after opening date!\n");
		        }
		    }
			

//			String name, String neighborhood, String type1, int noType1, int priceType1, String type2, int noType2, int priceType2, LocalDate openDate, LocalDate closeDate, String managerStr, int officerSlot, List<String> officersStr  

			Project newProj = new Project(name, neighbourhood,"2-room", notype1, pricetype1,"3-room", notype2, pricetype2,openDate, closeDate, this.getNric(),officerSlot,null, false , null);

			projectList.add(newProj);
			System.out.println("Project " + newProj.getName() + " added successfully!");
			System.out.println("\nYou can review the New Project in - View My Project List");
		}
	}

	// EDIT A PROJECT 
	public void editProject(Scanner scanner, List<Project> projectList) {
		UIHelper.printAction("Edit My Project");
		
		int i = 1;
		
		selectedProject = selectProjectFromMyProjects(projectList, scanner);
	    if (selectedProject == null) return;

		
		System.out.println();
		
		UIHelper.printProjectHeader("Current Project Details:");
		printProjectDetails(selectedProject);
		UIHelper.printDivider();
		System.out.println();
		
		System.out.println("Which Field do you want to edit?");

		
		String detail = scanner.nextLine().trim();

		switch (detail) {
		case "1" : {
			System.out.print("Enter the new name of the project: ");
			selectedProject.setName(scanner.nextLine());
			break;
		}
		case "2" : {
			System.out.print("Enter new neighbourhood: ");
			selectedProject.setNeighborhood(scanner.nextLine());
			break;
		}
		case "3" : {
			System.out.print("Enter new number of officer slots: ");
			selectedProject.setOfficerSlot(Integer.parseInt(scanner.nextLine()));
			break;
		}
		case "4" : {
			System.out.print("Enter new number of 2-room units: ");
			selectedProject.setNoType1(Integer.parseInt(scanner.nextLine()));
			break;
		}
		case "5" : {
			System.out.print("Enter new number of 3-room units: ");
			selectedProject.setNoType2(Integer.parseInt(scanner.nextLine()));
			break;
		}
		case "6" : {
			System.out.print("Enter new price of 2-room: ");
			selectedProject.setPriceType1(Integer.parseInt(scanner.nextLine()));
			break;
		}
		case "7" : {
			System.out.print("Enter new price of 3-room: ");
			selectedProject.setPriceType2(Integer.parseInt(scanner.nextLine()));
			break;
		}
		case "8" : {
			System.out.print("Enter new application open date (dd/MM/yyyy): ");
			DateTimeFormatter fdate = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			selectedProject.setOpenDate(LocalDate.parse(scanner.nextLine(), fdate));
			break;
		}
		case "9" : {
			System.out.print("Enter new application close date (dd/MM/yyyy): ");
			DateTimeFormatter fdate = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			selectedProject.setCloseDate(LocalDate.parse(scanner.nextLine(), fdate));
			break;
		}
		case "10" : {
			System.out.println("Enter " + selectedProject.getOfficerSlot()+" list of Officers:");
			String officerInput = scanner.nextLine().trim();
			List<String> updatedOfficers = new ArrayList<>();
			for (String officer : officerInput.split(",")) {
				updatedOfficers.add(officer.trim());
			}
			selectedProject.setOfficersStr(updatedOfficers);
			break;
		}
		case "11" : {
			UIHelper.printDivider();
			System.out.println("Toggling visibility status...");
			UIHelper.printDivider();
			selectedProject.toggleVisibility(!selectedProject.isVisible());
			System.out.println("New Visibility Status: " + (selectedProject.isVisible() ? "ON" : "OFF"));
			break;
		}
		default : System.out.println("Invalid selection....");
	}
	System.out.println("Updated Successfully!");
	}

	//DELETE A PROJECT
		public void deleteEntry(Scanner scanner, List<Project> projectList) {
			UIHelper.printAction("Delete an Existing Project");

			myProjects = filter.filterMyProject(projectList, this.getNric());
			

			boolean exit = false;
			while (!exit) {
				if (myProjects.isEmpty()) {
					System.out.println("There are no Projects to Delete.....");
					UIHelper.printDivider();
					return;
				}

				printProjectSelectionMenu(myProjects);

				System.out.print("Which Project would you like to Delete? ");
				String input = scanner.nextLine();

				try {
					int index = Integer.parseInt(input) - 1;

					if (index < 0 || index >= projectList.size()) {
						System.out.println("The number is not in the list!");
					} else {
//						Project removed = projectList.remove(index);
//						System.out.println("You are now deleting: " , )
						Project removed = myProjects.get(index);
						projectList.remove(removed);
						System.out.println("\nThe Project Deleted was: " + removed.getName());
						
						setActiveProject(projectList);
						
						exit = true;
					}
				} catch (NumberFormatException e) {
					System.out.println("Please enter a valid number....");
				}
			}
		}

		// SEE MY PROJECTS
		public void seeMyProjectList(List<Project> projectList) {
			UIHelper.printAction("View My Projects");
		myProjects = filter.filterMyProject(projectList, this.getNric());
		for (Project p : myProjects) {
			System.out.println();
			UIHelper.printProjectHeader("My Project Details");
			printProjectDetails(p);
			UIHelper.printDivider();
		}
	}
		// SEE ALL PROJECTS
	public void seeAllProjectList(List<Project> projectList) {
		UIHelper.printAction("View All Projects");
		for(Project p : projectList) {
			System.out.println();
			UIHelper.printProjectHeader("All Project Details");
			printProjectDetails(p);
			UIHelper.printDivider();
			
		}
	}
	
	// TOGGLE VISIBILITY
	public void toggleVisibility(Scanner scanner, List<Project> projectList) {
		UIHelper.printAction("Toggle Project Visibility Status");
		myProjects = filter.filterMyProject(projectList, this.getNric());
		UIHelper.printProjectHeader("Visibility Status of each Project");
		
		int i = 1;
		for (Project p : myProjects) {
			System.out.println(i + ". " + p.getName() + "status is " + (p.isVisible() ? "ON" : "OFF"));
			i++;
			
		}
		UIHelper.printDivider();
		System.out.println();
		System.out.println("Which Project do you want to Toggle Visibility?");
		String choice = scanner.nextLine().trim();
		
		int target = Integer.parseInt(choice) - 1;
		
		selectedProject = myProjects.get(target);
		
		selectedProject.toggleVisibility(!selectedProject.isVisible()); //eror
		
		System.out.println("Toggling Visibility....");
		
		System.out.println("Updated Visibility Status: " + (selectedProject.isVisible() ? "ON" : "OFF"));
		
		
		
	}
	
	//   VIEW ALL ENQUIRIES
	public void viewallEnquiries(List<Project> projectList) {
		UIHelper.printAction("View Enquiries of All Projects");
	boolean exit = false;
	int index = 0;
	while (!exit) {
		UIHelper.printProjectHeader("All Project List");
		System.out.println("Choose the Project to view the Enquiries");
		int i = 1;
//		UIHelper.lower("The enquiries");

		for (Project p : projectList) {
			System.out.println(i + ": " + p.getName());
			i++;
		}
		
		UIHelper.printDivider();
		System.out.println("Enter your choice");
		try {
			index = Integer.parseInt(scanner.nextLine().trim()) - 1;
			if (index < 0 || index >= projectList.size()) {
				System.out.println("Invalid selection.");
			} else {
				exit = true;
			}
		} catch (NumberFormatException e) {
			System.out.println("Invalid input. Please enter a number.");
		}

	}
	selectedProject = projectList.get(index);
	System.out.println("You have selected Project " + selectedProject.getName());

	List<Inquiry> inquiryList = selectedProject.getInquiries();


	if (inquiryList.isEmpty()) {
		System.out.println("\nNo Enquiries!");
		return;
	}
	else {
		UIHelper.printSubHeader(selectedProject.getName() + " Enquiries");

		for (int i = 0; i < inquiryList.size(); i++) {
			System.out.println();
			Inquiry inquiry = inquiryList.get(i);
			System.out.println((i + 1) + ". " + inquiry.toString());
			UIHelper.printDivider();
		}
	}
}
	
	// APPROVE OFFICERS
	public void approverejectOfficers(List<Project> projectList) {
		UIHelper.printAction("Approve or Reject Officer Applications");

		selectedProject = selectProjectFromMyProjects(projectList, scanner);
		if (selectedProject == null) return;

	    Map<Officer, Project> allPending = Officer.getPendingOfficers();
	    List<Officer> pendingOfficers = new ArrayList<>();

	    for (Map.Entry<Officer, Project> entry : allPending.entrySet()) {
	        if (entry.getValue() == selectedProject) {
	            pendingOfficers.add(entry.getKey());
	        }
	    }
	    
	    UIHelper.printDivider();

	    if (pendingOfficers.isEmpty()) {
	        System.out.println("\nNo Officers have registered for this project.");
	        return;
	    }

	    UIHelper.printSubHeader("Pending Officers for : " + selectedProject.getName());
	    for (Officer officer : pendingOfficers) {
	        UIHelper.printField("Name", officer.getName());
	        UIHelper.printField("NRIC", officer.getNric());
	        UIHelper.printField("Age", String.valueOf(officer.getAge()));
	        UIHelper.printDivider();
	    }
	    
	    UIHelper.printField("\nInitial available slots: ",String.valueOf(selectedProject.getOfficerSlot()));

	    while (true) {
	        if (selectedProject.getOfficerSlot() <= 0) {
	            System.out.println("No more officer slots available.");
	            break;
	        }

	        System.out.print("Enter Officer NRIC to approve/reject (0 to exit): ");
	        String nric = scanner.nextLine().trim().toUpperCase();

	        if (nric.equalsIgnoreCase("0")) break;

	        Officer targetOfficer = null;
	        for (Officer officer : pendingOfficers) {
	            if (officer.getNric().equalsIgnoreCase(nric)) {
	                targetOfficer = officer;
	                break;
	            }
	        }

	        if (targetOfficer == null) {
	            System.out.println("No pending officer found with that NRIC.");
	            continue;
	        }

	        System.out.print("Approve (A) / Reject (R)? ");
	        String reply = scanner.nextLine().trim();

	        switch (reply.toUpperCase()) {
	            case "A":
	            	selectedProject.getOfficersStr().add(targetOfficer.getNric());
	                Officer.getPendingOfficers().remove(targetOfficer);
	                selectedProject.setOfficerSlot(selectedProject.getOfficerSlot() - 1);
	                System.out.println("Officer " + targetOfficer.getName() + " approved and added to project.");
	                System.out.println("Remaining slots: " + selectedProject.getOfficerSlot());
	                break;

	            case "R":
	                Officer.getPendingOfficers().remove(targetOfficer);
	                System.out.println("Officer " + targetOfficer.getName() + " rejected.");
	                break;

	            default:
	                System.out.println("Invalid input.");
	                break;
	        }
	        
	        
	        pendingOfficers.remove(targetOfficer);
	    }
	}

	// APPROVE APPLICANTS
	public void approveRejectApplicants(List<Project> projectList) {
		UIHelper.printAction("Approve or Reject Project Applications");

		selectedProject = selectProjectFromMyProjects(projectList, scanner);
		if (selectedProject == null) return;
		
	    Map<Applicant, Project> allPending = Applicant.getPendingApplication();
	    List<Applicant> pendingApp = new ArrayList<>();

	    for (Map.Entry<Applicant, Project> entry : allPending.entrySet()) {
	        if (entry.getValue() == selectedProject) {
	            pendingApp.add(entry.getKey());
	        }
	    }

	    UIHelper.printDivider();

	    if (pendingApp.isEmpty()) {
	        System.out.println("\nNo Applicants have applied for this project.");
	        return;
	    }

	    UIHelper.printProjectHeader("Pending Applications for : " + selectedProject.getName());
	    for (Applicant applicant : pendingApp) {
	        UIHelper.printField("Name", applicant.getName());
	        UIHelper.printField("NRIC", applicant.getNric());
	        UIHelper.printField("Age", String.valueOf(applicant.getAge()));
	        UIHelper.printField("Flat Type", applicant.getAppliedType());
	        UIHelper.printDivider();
	    }
	    
	    System.out.println("\nInitial 2-room units: " + selectedProject.getNoType1());
	    System.out.println("Initial 3-room units: " + selectedProject.getNoType2());

	    while (!pendingApp.isEmpty()) {
	        System.out.print("Enter Applicant NRIC to approve/reject (or type '0' to exit): ");
	        String nric = scanner.nextLine().trim().toUpperCase();

	        if (nric.equals("0")) {
	        	break;
	        }

	        Applicant targetApp = null;
	        for (Applicant applicant : pendingApp) {
	            if (applicant.getNric().equalsIgnoreCase(nric)) {
	                targetApp = applicant;
	                break;
	            }
	        }

	        if (targetApp == null) {
	            System.out.println("No pending Application found with that NRIC.");
	            continue;
	        }

	        System.out.print("Approve (A) / Reject (R)? ");
	        String reply = scanner.nextLine().trim();

	        switch (reply.toUpperCase()) {
	            case "A":
	                String type = targetApp.getAppliedType();
	                if (type.equalsIgnoreCase("2-Room")) {
	                    if (selectedProject.getNoType1() <= 0) {
	                        System.out.println("No 2-room units left. Cannot approve any more Applicants.");
	                        break;
	                    }
	                    selectedProject.setNoType1(selectedProject.getNoType1() - 1);
	                } else if (type.equalsIgnoreCase("3-Room")) {
	                    if (selectedProject.getNoType2() <= 0) {
	                        System.out.println("No 3-room units left. Cannot approve any more Applicants.");
	                        break;
	                    }
	                    selectedProject.setNoType2(selectedProject.getNoType2() - 1);
	                } else {
	                    System.out.println("Unknown flat type.");
	                    break;
	                }

	                targetApp.setApplicationStatus("Successful");
	                selectedProject.addApprovedApplicant(targetApp);  
	                Applicant.getPendingApplication().remove(targetApp);
	                System.out.println("Applicant " + targetApp.getName() + " approved.");
	                break;

	            case "R":
	                targetApp.setApplicationStatus("Unsuccessful");
	                selectedProject.removeApplicant(targetApp);
	                Applicant.getPendingApplication().remove(targetApp);
	                System.out.println("Applicant " + targetApp.getName() + " rejected.");
	                break;

	            default:
	                System.out.println("Invalid input. Skipping.");
	                break;
	        }

	        pendingApp.remove(targetApp);
	        UIHelper.printField("Remaining 2-room units", String.valueOf(selectedProject.getNoType1()));
	        UIHelper.printField("Remaining 3-room units", String.valueOf(selectedProject.getNoType2()));
	    }
	}
		
	// REPLY TO MY ENQUIRIES
	public void replytoEnquiries(List<Project> projectList) {
		UIHelper.printAction("Reply to Your Project Enquiries");
		
		boolean exit = false;
		int index = 0;
		
		while (!exit) {
			
			selectedProject = selectProjectFromMyProjects(projectList, scanner);
			if (selectedProject == null) return;
			
			
//			printProjectSelectionMenu(myProjects);
//			System.out.println("Enter your choice");

			try {
				index = Integer.parseInt(scanner.nextLine().trim()) - 1;
				if (index < 0 || index >= projectList.size()) {
					System.out.println("Invalid selection.");
				} else {
					exit = true;
				}
			} catch (NumberFormatException e) {
				System.out.println("Invalid input. Please enter a number.");
			}
		}
//		selectedProject = projectList.get(index);
		System.out.println("You selected project: " + selectedProject.getName());

		List<Inquiry> inquiryList = selectedProject.getInquiries();

		if (inquiryList.isEmpty()) {
			System.out.println("No Enquiries!");
			return;
		}

		List<Inquiry> pendingList = new ArrayList<>();
		for (Inquiry inquiry : inquiryList) {
			if (!inquiry.isReplied()) {
				pendingList.add(inquiry);
			}
		}
		
		UIHelper.printSubHeader(selectedProject.getName() + " Enquiries");
		
		if (pendingList.isEmpty()){
			System.out.println("No more Pending Enquiries in this Project!");
		}
		else {
			for (int i = 0; i < pendingList.size(); i++) {
				Inquiry inquiry = pendingList.get(i);
				System.out.println((i+1) + "From: " + inquiry.getApplicant().getName());
				System.out.println("Message: "+ inquiry.getMessage());
				
				UIHelper.printDivider();
			}
			System.out.println("Which Enquiry do you want to reply to?");
			int enqno = Integer.parseInt(scanner.nextLine().trim()) - 1;
			if (enqno < 0 || enqno >= pendingList.size()) {
				System.out.println("Invalid enquiry number.");
			} else {
				Inquiry message = pendingList.get(enqno);
				System.out.println("You are replying to: " + message.getMessage());
				System.out.println("Enter Reply: ");
				String Reply = scanner.nextLine();
				message.setReply(Reply);
				System.out.println("Reply saved: " + message.getReply());

				pendingList.remove(enqno);
			}
		}
	}
	
	
	
	// APPROVE APPLICANTS WITHDRAWAL
	public void approveRejectWithdrawals(List<Project> projectList) {
		UIHelper.printAction("Approve or Reject Applicant Withdrawal");
		
		selectedProject = selectProjectFromMyProjects(projectList, scanner);
		if (selectedProject == null) return;
	    
	    Map<Applicant, Project> AppWith = Applicant.ApplicationWithdrawal;
	    List<Applicant> WithdrawApplicants = new ArrayList<>();

	    for (Map.Entry<Applicant, Project> entry : AppWith.entrySet()) {
	        if (entry.getValue() == selectedProject) {
	            WithdrawApplicants.add(entry.getKey());
	        }
	    }
	    
	    UIHelper.printDivider();

	    if (WithdrawApplicants.isEmpty()) {
	        System.out.println("\nNo Withdrawal Application for " + selectedProject.getName());
	        return;
	    }
	    
	    UIHelper.printProjectHeader("Pending Withdrawal Applications for: " + selectedProject.getName());
	    
	    for(Applicant applicants : WithdrawApplicants) {
	    	UIHelper.printField("Name", applicants.getName());
	        UIHelper.printField("NRIC", applicants.getNric());
	        UIHelper.printDivider();
	    }
	    
	    System.out.print("Enter Applicant NRIC to approve/reject  ");
        String nric = scanner.nextLine().trim().toUpperCase();
        
        Applicant targetapp = null;
        for (Applicant app : WithdrawApplicants) {
            if (app.getNric().equalsIgnoreCase(nric)) {
                targetapp = app;
                break;
            }
        }
        
        if (targetapp == null) {
        	System.out.println("\nNo Applicant found with that NRIC.");
        	return;

        }
        
        System.out.print("Approve (A) / Reject (R)? ");
        String reply = scanner.nextLine().trim();
        
        switch (reply.toUpperCase()) {
        	case "A":
        		UIHelper.printDivider();
        		System.out.println("Withdrawal Application Approved");
        		UIHelper.printDivider();
        		Applicant.ApplicationWithdrawal.remove(targetapp);
        		
        		String type = targetapp.getAppliedType();
        	    if (type != null) {
        	        if (type.equalsIgnoreCase("2-Room")) {
        	            targetapp.getAppliedProject().setNoType1(
        	                targetapp.getAppliedProject().getNoType1() + 1
        	            );
        	        } 
        	        else if (type.equalsIgnoreCase("3-Room")) {
        	            targetapp.getAppliedProject().setNoType2(
        	                targetapp.getAppliedProject().getNoType2() + 1
        	            );
        	        }
        	    }
        		targetapp.getAppliedProject().getApprovedApplicants().remove(targetapp);
        		targetapp.getAppliedProject().removeApplicant(targetapp);
        	    targetapp.setApplicationStatus("N/A");
        	    targetapp.setAppliedProject(null);
        	    targetapp.setAppliedType("");
        	    Applicant.pendingApplication.remove(targetapp); //jic
        		break;
        	case "R":
        		System.out.println("Withdrawal Application Rejected");
        		Applicant.ApplicationWithdrawal.remove(targetapp);
        		Applicant.pendingApplication.put(targetapp, selectedProject);
        		break;
        	default:
        		System.out.println("Invalid input");
        		break;
        		
        		
        }
        	
 }
	//GENERATE APPLICANT REPOT
	
	public void generateApplicantReport(List<Project> projectList) {
		UIHelper.printAction("Generate Project Report");

		selectedProject = selectProjectFromMyProjects(projectList, scanner);
		if (selectedProject == null) return;

		UIHelper.printDivider();
		System.out.println("By Which Field do you want to Filter?");
		UIHelper.printDivider();
		System.out.println("1. Flat Type                   | 2. Project Name");
		System.out.println("3. Applicant's Maritial Status | 4. Applicant's Age");
		UIHelper.printDivider();
		int field = Integer.parseInt(scanner.nextLine().trim());

		List<Applicant> applicants = selectedProject.getApprovedApplicants();
		List<Applicant> filteredApplicants = new ArrayList<>();

		switch (field) {
			case 1:
				System.out.println("By which Flat Type?  1. 2-Room | 2. 3-Room");
				int flatTypeChoice = Integer.parseInt(scanner.nextLine().trim());
				String typeFilter = (flatTypeChoice == 1) ? "2-Room" : "3-Room";
				for (Applicant app : applicants) {
					if (app.getAppliedType().equalsIgnoreCase(typeFilter)) {
						filteredApplicants.add(app);
					}
				}
				break;

			case 2: 
				String projName = selectedProject.getName().trim();
				for (Applicant app : applicants) {
					if (app.getAppliedProject().getName().equalsIgnoreCase(projName)) {
						filteredApplicants.add(app);
					}
				}
				break;

			case 3: 
				System.out.print("Enter Marital Status to Filter (Single/Married): ");
				String statusFilter = scanner.nextLine().trim();
				for (Applicant app : applicants) {
					if (app.getMaritalStatus().equalsIgnoreCase(statusFilter)) {
						filteredApplicants.add(app);
					}
				}
				break;

			case 4: 
				System.out.print("Enter Minimum Age: ");
				int minAge = Integer.parseInt(scanner.nextLine().trim());
				System.out.print("Enter Maximum Age: ");
				int maxAge = Integer.parseInt(scanner.nextLine().trim());
				for (Applicant app : applicants) {
					if (app.getAge() >= minAge && app.getAge() <= maxAge) {
						filteredApplicants.add(app);
					}
				}
				break;

			default:
				System.out.println("Invalid filter option.");
				return;
		}

		UIHelper.printDivider();
		System.out.println("Filtered Applicant Report for Project: " + selectedProject.getName());
		UIHelper.printDivider();

		if (filteredApplicants.isEmpty()) {
			System.out.println("No applicants found for the selected filter.");
		} else {
			for (Applicant app : filteredApplicants) {
				UIHelper.printField("Name", app.getName());
				UIHelper.printField("NRIC", app.getNric());
				UIHelper.printField("Age", String.valueOf(app.getAge()));
				UIHelper.printField("Marital Status", app.getMaritalStatus());
				UIHelper.printField("Applied Flat Type", app.getAppliedType());
				UIHelper.printDivider();
			}
		}
	}

	// TO CHOOSE MANAGER SELECTIVE
	private void printProjectSelectionMenu(List<Project> projects) {
	    UIHelper.printProjectHeader("MY PROJECTS");
	    for (int i = 0; i < projects.size(); i++) {
	        System.out.println((i + 1) + ": " + projects.get(i).getName());
	    }
	    UIHelper.printDivider();
	}
	
	// TO SHOW PROJECT DETAILS 
	private void printProjectDetails(Project p) {
	    UIHelper.printField("1. Name", p.getName());
	    UIHelper.printField("2. Neighbourhood", p.getNeighborhood());
	    UIHelper.printField("3. Number of OfficerSlots", String.valueOf(p.getOfficerSlot()));
	    UIHelper.printField("4. Number of 2-room units", String.valueOf(p.getNoType1()));
	    UIHelper.printField("5. Number of 3-room units", String.valueOf(p.getNoType2()));
	    UIHelper.printField("6. Price of 2-room", String.valueOf(p.getPriceType1()));
	    UIHelper.printField("7. Price of 3-room", String.valueOf(p.getPriceType2()));
	    UIHelper.printField("8. Application open-date", p.getOpenDate().toString());
	    UIHelper.printField("9. Application close-date", p.getCloseDate().toString());

	    List<String> officers = p.getOfficersStr();
	    if (officers == null || officers.isEmpty()) {
	        UIHelper.printField("10. Officers Assigned", "None yet");
	    } else {
	        UIHelper.printField("10. Officers Assigned", String.join(", ", officers));
	    }

	    UIHelper.printField("11. Visibility", p.isVisible() ? "ON" : "OFF");
	}

	
	// TO SHOW MANAGER PROJECTS
	private Project selectProjectFromMyProjects(List<Project> projectList, Scanner scanner) {
	    myProjects = filter.filterMyProject(projectList, this.getNric());

	    if (myProjects.isEmpty()) {
	        System.out.println("You currently have no projects to manage.");
	        return null;
	    }

	    printProjectSelectionMenu(myProjects);

	    System.out.print("Which Project do you want to handle? ");
	    int target = Integer.parseInt(scanner.nextLine().trim()) - 1;

	    if (target < 0 || target >= myProjects.size()) {
	        System.out.println("Invalid project number selected.");
	        return null;
	    }

	    return myProjects.get(target);
	}


		


	// MANAGER MENU 
	public String showInterface(Scanner scanner, List<Project> projectList) {
    	System.out.println();
    	System.out.println("[ LOGIN SUCCESSFUL ] Welcome, " + getName() + "!\n");
    	setActiveProject(projectList);
    	Project current = getActiveProject();
    	if (current != null) {
    	    UIHelper.printProjectHeader("Your Active Project is " + current.getName());
    	} else {
    	    UIHelper.printProjectHeader("You have no Active Project at the moment..");
    	}

//    	System.out.println("NRIC : " + getNric());

    	while (true) {

    	    UIHelper.printHeader("MANAGER MENU");

    	    // System.out.println("Logged in as: " + getName() + " (" + getNric() + ")");
    	    // System.out.println();

    	    System.out.println("Choose an action:");
    	    System.out.println(" 1. Add New Project");
    	    System.out.println(" 2. Edit Project");
    	    System.out.println(" 3. Delete Project");
    	    System.out.println(" 4. View My Project List");
    	    System.out.println(" 5. View All Project List");
    	    System.out.println(" 6. Toggle Project Visibility");
    	    System.out.println(" 7. View All Project Enquiries");
    	    System.out.println(" 8. Reply to Your Project Enquiries");
    	    System.out.println(" 9. Approve/Reject Officers");
    	    System.out.println("10. Approve/Reject Applicants");
    	    System.out.println("11. Approve/Reject Applicant Withdrawal");
    	    System.out.println("12. Generate a Report");
    	    System.out.println("13. Reset Password");
    	    System.out.println("14. Logout");
    	    System.out.println("15. Quit App");

    	    UIHelper.printProjectFooter();

    	    System.out.print("\nEnter your choice: ");
    	    String input = scanner.nextLine().trim();

    	    switch (input) {
    	        case "1":
    	            setActiveProject(projectList);
    	            createProject(scanner, projectList);
    	            break;
    	        case "2":
    	            editProject(scanner, projectList);
    	            break;
    	        case "3":
    	            deleteEntry(scanner, projectList);
    	            break;
    	        case "4":
    	            seeMyProjectList(projectList);
    	            break;
    	        case "5":
    	            seeAllProjectList(projectList);
    	            break;
    	        case "6":
    	            toggleVisibility(scanner, projectList);
    	            break;
    	        case "7":
    	            viewallEnquiries(projectList);
    	            break;
    	        case "8":
    	            replytoEnquiries(projectList);
    	            break;
    	        case "9":
    	            approverejectOfficers(projectList);
    	            break;
    	        case "10":
    	            approveRejectApplicants(projectList);
    	            break;
    	        case "11":
    	            approveRejectWithdrawals(projectList);
    	            break;
    	        case "12":
    	        	generateApplicantReport(projectList);
    	            break;
    	        case "13":
    	            return resetPassword(scanner);
    	        case "14":
    	            System.out.println("Logging out....");
    	            return "logout";
    	        case "15":
    	            return "quit";
    	        default:
    	            System.out.println("Invalid choice. Please try again.");
    	            break;
    	    }

    	    }
	}
}

	

		
	



