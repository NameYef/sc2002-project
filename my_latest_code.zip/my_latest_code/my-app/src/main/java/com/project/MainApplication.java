package com.project;

import java.io.IOException;
import java.util.*;

public class MainApplication {

    public static void main(String[] args) {
        boolean run = true;
        Scanner scanner = new Scanner(System.in);
        ExcelReader reader = new ExcelReader();

        try {
            // Load data from Excel
            List<Project> projectList = reader.readProjects("C:\\Shivaani\\java_bto_new\\sc2002-project (1)\\sc2002-project\\data\\ProjectList.xlsx");
            List<Applicant> applicantList = reader.readApplicants("C:\\Shivaani\\java_bto_new\\sc2002-project (1)\\sc2002-project\\data\\ApplicantList.xlsx");
            List<Manager> managerList = reader.readManagers("C:\\Shivaani\\java_bto_new\\sc2002-project (1)\\sc2002-project\\data\\ManagerList.xlsx");
            List<Officer> officerList = reader.readOfficers("C:\\Shivaani\\java_bto_new\\sc2002-project (1)\\sc2002-project\\data\\OfficerList.xlsx");
            

            // Combine all users for login
            List<User> allUsers = new ArrayList<>();
            allUsers.addAll(applicantList);
            allUsers.addAll(managerList);
            allUsers.addAll(officerList);

            LoginService loginService = new LoginService(allUsers);
            User currentUser = null;

            while (run) {
                currentUser = loginService.login(scanner);
                if (currentUser == null) continue;

                boolean loggedIn = true;
                while (loggedIn) {
                    String action = currentUser.showInterface(scanner, projectList);
                    switch (action) {
                        case "logout" -> {
                            loggedIn = false;
                            currentUser = null;
                        }
                        case "quit" -> {
                            loggedIn = false;
                            run = false;
                        }
                    }
                }
            }

            System.out.println("Terminating...");

        } catch (IOException e) {
            System.out.println("Error reading Excel files: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
