package com.project;
public interface IInquiry {
    void submitInquiry(String inquiry);
    void editInquiry(String newInquiry);
    void deleteInquiry();
    void viewInquiries();
}
