//package com.project;
//
//import java.util.Objects;
//import java.util.Scanner;
//import java.util.List;
//import java.util.ArrayList;
//import java.time.LocalDate;
//import java.time.format.DateTimeFormatter;
//
//public class Manager extends User {
//
//	private List<Project> pendingprojects;
//	Project selectedProject = null;
//
//	public Manager(String name, String nric, int age, String maritalStatus, String password) {
//		super(name, nric, age, maritalStatus, password);
//	}
//
//	@Override
//	public String getRole() {
//		return "Manager";
//	}
//
//	String status = "ON";
//
//
//	private List<Project> projectList = new ArrayList<>();
//
//	Scanner scanner = new Scanner(System.in);
//
//	public void addEntry(Scanner scanner, List<Project> projectList) {
//		
//		LocalDate today = LocalDate.now();
//
//	    boolean hasActiveProject = projectList.stream()
//	        .anyMatch(p ->
//	            p.getManager().equals(this.getNric()) &&
//	            p.isVisible() &&
//	            (today.isBefore(p.getCloseDate().plusDays(1)) && today.isAfter(p.getOpenDate().minusDays(1)))
//	        );
//
//	    if (hasActiveProject) {
//	        System.out.println("You already have an active project during the application period. Cannot create another one.");
//	        return;
//	    }
//		
//		DateTimeFormatter dateForm = DateTimeFormatter.ofPattern("dd/MM/yyyy");
//		List<String> officersString = new ArrayList<>();
//
//		System.out.println("Enter name of project:");
//		String name = scanner.nextLine();
//
//		System.out.println("Enter name of neighbourhood:");
//		String neighbourhood = scanner.nextLine();
//
//		System.out.print("Enter flat type 1: \n");
//		String type1 = UIHelper.readFlatType(scanner);
//
//		System.out.println("Enter the number of " + type1 + " flats:");
//		int notype1 = Integer.parseInt(scanner.nextLine());
//
//		System.out.println("Enter the price of " + type1 + " flats:");
//		double pricetype1 = Double.parseDouble(scanner.nextLine());
//
//		System.out.print("Enter flat type 2: \n");
//		String type2 = UIHelper.readFlatType(scanner);
//
//		System.out.println("Enter the number of " + type2 + " flats:");
//		int notype2 = Integer.parseInt(scanner.nextLine());
//
//		System.out.println("Enter the price of " + type2 + " flats:");
//		double pricetype2 = Double.parseDouble(scanner.nextLine());
//
//		System.out.println("Enter application opening date (dd/MM/yyyy):"); // made changes to the date format for now (if dont like can remove later)
//		LocalDate openDate = LocalDate.parse(scanner.nextLine(), dateForm);
//
//		System.out.println("Enter application closing date (dd/MM/yyyy):");
//		LocalDate closeDate = LocalDate.parse(scanner.nextLine(), dateForm);
//
//		System.out.println("Enter the number of officers to undertake the project:");
//		int officerSlot = Integer.parseInt(scanner.nextLine());
//
//		for (int i = 1; i <= officerSlot; i++) {
//			System.out.printf("Enter Name of officer no. %d: ", i);
//			String officerStr = scanner.nextLine();
//			officersString.add(officerStr);
//		}
//
//		Project newProj = new Project(
//				name, neighbourhood, type1, notype1, pricetype1,
//				type2, notype2, pricetype2,
//				openDate, closeDate, type2, officerSlot, officersString, getNric());
//
//		projectList.add(newProj);
//		System.out.println("Project added successfully.");
//	}
//
//	public void deleteEntry(Scanner scanner, List<Project> projectList) {
//		boolean exit = false;
//		while (!exit) {
//			if (projectList.isEmpty()) {
//				System.out.println("There are no projects to delete.");
//				return;
//			}
//
//			// display existing projects
//			System.out.println("Projects:");
//			for (int i = 0; i < projectList.size(); i++) {
//				Project p = projectList.get(i);
//				System.out.println((i + 1) + ". " + p.getName() + " (" + p.getNeighborhood() + ")");
//			}
//
//			System.out.print("Enter the number of the project to delete: ");
//			String input = scanner.nextLine();
//
//			try {
//				int index = Integer.parseInt(input) - 1;
//
//				if (index < 0 || index >= projectList.size()) {
//					System.out.println("The number is not in the list!");
//				} else {
//					Project removed = projectList.remove(index);
//					System.out.println("The project Deleted was: " + removed.getName());
//					exit = true;
//				}
//			} catch (NumberFormatException e) {
//				System.out.println("Please enter a valid number....");
//			}
//		}
//	}
//
//
//	public void toggleVisibility(Scanner scanner, List<Project> projectList) {
//		int i = 1;
//		System.out.println("Which Project do you want to check the visibility status?");
//		for (Project project : projectList) {
//			System.out.println(i + ": " + project.getName());
//			i++;
//		}
//		System.out.println("Enter your choice: ");
//		String choice = scanner.nextLine().trim();
//		int target = Integer.parseInt(choice);
//
//
//		if (target < 1 || target > projectList.size()) {
//			System.out.println("Invalid choice!");
//		} else {
//			selectedProject = projectList.get(target - 1);
//			System.out.println("Current Visibility of " + selectedProject.getName() + ": " + (selectedProject.isVisible() ? "ON" : "OFF"));
//			System.out.println("Do you want to toggle the visibility? Y/N");
//			String answer = scanner.nextLine().trim();
//
//			if (answer.equalsIgnoreCase("Y")) {
//
//
//
//				selectedProject.toggleVisibility(!selectedProject.isVisible());
//				System.out.println("Visibility toggled to: " + (selectedProject.isVisible() ? "ON" : "OFF"));
//
//			} else if (answer.equalsIgnoreCase("N")) {
//				System.out.println("Visibility Status not toggled");
//			}
//		}
//	}
//
//	public void seeProjectList(List<Project> projectList) {
//		for (Project p : projectList) {
//			UIHelper.lower("Project details");
//			System.out.println("Name: " + p.getName());
//			System.out.println("Neighborhood: " + p.getNeighborhood());
//			System.out.println(String.format("Type1: %-10s | Units: %02d | Price: $%.2f", p.getType1(), p.getNoType1(), (double) p.getPriceType1()));
//			System.out.println(String.format("Type2: %-10s | Units: %02d | Price: $%.2f",p.getType2(), p.getNoType2(), (double) p.getPriceType2()));
//
//
//			System.out.println("Open Date: " + p.getOpenDate());
//			System.out.println("Close Date: " + p.getCloseDate());
//			System.out.println("Manager in-charge: " + p.getManager()); 
//
//			System.out.println("Manager NRIC: " + p.getManagerNRIC());
//			System.out.println("Officer Slots: " + p.getOfficerSlot());
//			System.out.println("Officer(s) in-charge: " + p.getOfficers());
//			System.out.println("------------------------");
//		}
//	}
//
//	public void viewallEnquiries(List<Project> projectList) {
//		boolean exit = false;
//		int index = 0;
//		while (!exit) {
//			UIHelper.printMenuHeader("All Project Enquiries");
//			System.out.println("Choose the project to view the Enquiries");
//			int i = 1;
////			UIHelper.lower("The enquiries");
//
//			for (Project p : projectList) {
//				System.out.println(i + ": " + p.getName());
//				i++;
//			}
//			try {
//				index = Integer.parseInt(scanner.nextLine().trim()) - 1;
//				if (index < 0 || index >= projectList.size()) {
//					System.out.println("Invalid selection.");
//				} else {
//					exit = true;
//				}
//			} catch (NumberFormatException e) {
//				System.out.println("Invalid input. Please enter a number.");
//			}
//
//		}
//		selectedProject = projectList.get(index);
//		System.out.println("You selected project: " + selectedProject.getName());
//
//		List<Inquiry> inquiryList = selectedProject.getInquiries();
//
//
//		if (inquiryList.isEmpty()) {
//			System.out.println("No Enquiries!");
//			return;
//		}
//		else {
//			UIHelper.lower("The enquiries");
//
//			for (int i = 0; i < inquiryList.size(); i++) {
//				Inquiry inquiry = inquiryList.get(i);
//				System.out.println((i + 1) + ". " + inquiry.getMessage());
//			}
//		}
//	}
//
////	public void replytoEnquiries(List<Project> projectList) {
////		boolean exit = false;
////		int index = 0;
////		while (!exit) {
////			UIHelper.printMenuHeader("Pending Enquiries");
////			System.out.println("Choose the project to reply the Enquiries: ");
////			int i = 1;
////
////			for (Project p : projectList) {
////
////				System.out.println(i + ": " + p.getName());
////				i++;
////			}
////
////			try {
////				index = Integer.parseInt(scanner.nextLine().trim()) - 1;
////				if (index < 0 || index >= projectList.size()) {
////					System.out.println("Invalid selection.");
////				} else {
////					exit = true;
////				}
////			} catch (NumberFormatException e) {
////				System.out.println("Invalid input. Please enter a number.");
////			}
////		}
////		selectedProject = projectList.get(index);
////		System.out.println("You selected project: " + selectedProject.getName());
////
////		List<Inquiry> inquiryList = selectedProject.getInquiries();
////
////		if (inquiryList.isEmpty()) {
////			System.out.println("No Enquiries!");
////			return;
////		}
////
////		List<Inquiry> pendingList = new ArrayList<>();
////		for (Inquiry inquiry : inquiryList) {
////			if (!inquiry.isReplied()) {
////				pendingList.add(inquiry);
////			}
////		}
////		UIHelper.lower("Enquires of " + selectedProject.getName() + "\n");
////		if (pendingList.isEmpty()){
////			System.out.println("No more Pending Enquiries in this Project!");
////		}
////		else {
////			for (int i = 0; i < pendingList.size(); i++) {
////				Inquiry inquiry = pendingList.get(i);
////				System.out.println((i + 1) + ". " + inquiry.getMessage());
////				System.out.println("   ~ No reply yet.");
////			}
////			System.out.println("Which Enquiry do you want to reply to?");
////			int enqno = Integer.parseInt(scanner.nextLine().trim()) - 1;
////			if (enqno < 0 || enqno >= pendingList.size()) {
////				System.out.println("Invalid enquiry number.");
////			} else {
////				Inquiry message = pendingList.get(enqno);
////				System.out.println("You are replying to: " + message.getMessage());
////				System.out.println("Enter Reply: ");
////				String Reply = scanner.nextLine();
////				message.setReply(Reply);
////				System.out.println("Reply saved: " + message.getReply());
////
////				pendingList.remove(enqno);
////			}
////		}
////	}
//
//	public void replyToEnquiries(List<Project> projectList) {
//
//        for (Project p : projectList) {
//
//			if (Objects.equals(p.getManager(), getName())) {
//
//				List<Inquiry> inquiries = p.getInquiries();
//				if (inquiries.isEmpty()) {
//					System.out.println(" No Enquiries.");
//				} else {
//					UIHelper.lower("Project Enquiries");
//
//					for (int j = 0; j < inquiries.size(); j++) {
//						Inquiry inq = inquiries.get(j);
//						System.out.println((j + 1) + ". From: " + inq.getApplicant().getName());
//						System.out.println("   Message: " + inq.getMessage());
//						System.out.println("   Reply: " + (inq.isReplied() ? inq.getReply() : "No reply yet"));
//
//						System.out.println("------------------------------------");
//					}
//				}
//            }
//		}
//	}
//
//
//
//	public void approverejectOfficers(List<Officer> officerList, List<Project> projectList) {
//		System.out.println("Approval of Officer Registrations (Not yet implemented):");
//		// You'll need a way to track pending officer registrations in your Officer class or globally.
//	}
//
//	public void approverejectApplicants(List<Applicant> applicants) {
//		for (Applicant a : applicants) {
//			if (a.getApplicationStatus().equalsIgnoreCase("pending")) {
//				System.out.println("Applicant: " + a.getName() + ", NRIC: " + a.getNric() +
//						" — Applied for: " + a.getAppliedProject().getName() + " (" + a.getAppliedType() + ")");
//				System.out.print("Approve (A) / Reject (R): ");
//
//				Scanner scanner = new Scanner(System.in);
//				String decision = scanner.nextLine().trim().toUpperCase();
//
//				if (decision.equals("A")) {
//					a.setApplicationStatus("successful");
//					System.out.println("Application approved.");
//				} else if (decision.equals("R")) {
//					a.setApplicationStatus("unsuccessful");
//					System.out.println("Application rejected.");
//				} else {
//					System.out.println("Invalid choice. Skipped.");
//				}
//			}
//		}
//	}
//
//
//	@Override
//
//	public String showInterface(Scanner scanner, List<Project> projectList) {
//
//		while (true) {
//			UIHelper.printMenuHeader("Manager Menu");
//			System.out.println(" Logged in as: " + getName() + " (" + getNric() + ")");
//			System.out.println("\nPlease choose an action:");
//			System.out.println("1. Add New Project");
//			System.out.println("2. Delete Project");
//			System.out.println("3. View Project List");
//			System.out.println("4. Toggle Project Visibility");
//			System.out.println("5. View Enquiries");
//			System.out.println("6. Reply to your Project Enquiries");
//			System.out.println("7. Approve/Reject Applicants");
//			System.out.println("8. Reset Password");
//			System.out.println("9. Logout");
//			System.out.println("10. Quit App");
//			System.out.print("\nEnter your choice: ");
//
//			String input = scanner.nextLine().trim();
//
//			switch (input) {
//
//				case "1":
//					addEntry(scanner, projectList);
//					break;
//				case "2":
//					deleteEntry(scanner, projectList);
//					break;
//				case "3":
//					seeProjectList(projectList);
//					break;
//				case "4":
//					toggleVisibility(scanner,projectList);
//					break;
//				case "5":
//					//viewenquires
//					viewallEnquiries(projectList);
//					break;
//				case "6":
//					replyToEnquiries(projectList);
//					break;
//				case "7":
////					approverejectApplicants(getAllApplicants(projectList)); // add helper if needed
//
//					break;
//				case "8":
//					return resetPassword(scanner);
//				case "9":
//					return "logout";
//				case "10":
//					return "quit";
//				default:
//					System.out.println("Invalid choice. Please try again.");
//
//			}
//		}
//	}
//}
//
